def greeting(name,age):
    print(f'Hello my name is {name}, I am {age}')
