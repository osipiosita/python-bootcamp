def convert(celcius):
     fahrenheit = (celcius * 9/5) + 32
     return fahrenheit