def calculate(base,expo):
    print(base, "raised to the power", expo, "=", base**expo)
