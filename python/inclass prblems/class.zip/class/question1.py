def count(integer):
    print(f'{integer} has {len(str(integer))}')

