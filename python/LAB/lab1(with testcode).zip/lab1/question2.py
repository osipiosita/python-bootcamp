'''
Test Code
Result: Sat Aug 26 15:08:19 2023
'''
import time
print(time.asctime())